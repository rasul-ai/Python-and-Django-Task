from django import forms
from .models import Trade

class TradeForm(forms.ModelForm):
    class Meta:
        model = Trade
        fields = '__all__'  # Or specify the fields you want to include in the form
