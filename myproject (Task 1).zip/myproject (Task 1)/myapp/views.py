# Initial phase
from django.shortcuts import render
import json

def home(request):
    with open('/home/bapary/Documents/Job_circular + Done_task/Janata_Wifi/stock_market_data.json') as f:
        data = json.load(f)
    return render(request, 'home.html', {'data': data})


## Enhanced phase
# from django.shortcuts import render, redirect, get_object_or_404
# from .models import Trade
# from .forms import TradeForm

# def trade_list(request):
#     trades = Trade.objects.all()
#     return render(request, 'trade_list.html', {'trades': trades})


# def trade_create(request):
#     if request.method == 'POST':
#         form = TradeForm(request.POST)
#         if form.is_valid():
#             form.save()
#             return redirect('trade_list')
#     else:
#         form = TradeForm()
#     return render(request, 'trade_form.html', {'form': form})


